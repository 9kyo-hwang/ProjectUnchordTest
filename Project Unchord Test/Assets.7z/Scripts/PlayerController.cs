using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    Rigidbody2D pRigid;
    PlayerInput pInput;
    private TrailRenderer trailRenderer;

    // �̵�
    public float defaultMoveSpeed;
    private float moveSpeed;

    // ���
    public float dashSpeed;
    public float defaultDashTime;
    private float dashTime;
    private bool isDashing;
    private bool canDash = true;
    private Vector2 dashDir;

    // ����.
    private bool canDoubleJump;
    public float jumpForce;

    // �� �׼�. �� �Ŵ޸���/�ö󰡱�/�������� �� �� ����
    public bool isWallHanging;
    private float gravityStore;
    public float wallMoveSpeed;
    public float wallJumpTime;
    private float wallJumpCounter;

    // �浹 üũ. �� ������δ� �� ���� �÷��̾ ��ġ�� ��� ���� ������ ���� ���� ����
    public float checkRadius;
    private bool isGround;
    public Transform groundCheck;
    public LayerMask groundLayer;
    private bool isFront;
    public Transform frontCheck;
    public LayerMask frontLayer;

    void Start()
    {
        pRigid = GetComponent<Rigidbody2D>();
        pInput = GetComponent<PlayerInput>();
        trailRenderer = GetComponent<TrailRenderer>();

        moveSpeed = defaultMoveSpeed;
        dashTime = defaultDashTime;
        gravityStore = pRigid.gravityScale;
    }
    private void Update()
    {
        CheckObject();
        FlipPlayer();
    }

    void FixedUpdate()
    {
        if (wallJumpCounter <= 0)
        {
            Move();
            Run();
            Jump();
            Dash();
            WallHanging();
            WallMove();
            WallJump();
        }
        else wallJumpCounter -= Time.deltaTime;
    }

    void Move()
    {
        pRigid.velocity = new Vector2(pInput.lrInput * moveSpeed, pRigid.velocity.y);
    }

    void Run()
    {
        moveSpeed = pInput.run ? defaultMoveSpeed * 2 : defaultMoveSpeed;
    }

    void Jump()
    {
        if(pInput.jumpButtonDown && isGround)
        {
            canDoubleJump = true;
            pRigid.velocity = Vector2.zero;
            pRigid.velocity = new Vector2(pRigid.velocity.x, jumpForce);
        }
        else if(pInput.jumpButtonDown && canDoubleJump)
        {
            pRigid.velocity = Vector2.zero;
            pRigid.velocity = new Vector2(pRigid.velocity.x, jumpForce);
            canDoubleJump = false;
        }
        if(pInput.jumpButtonUp && pRigid.velocity.y > 0)
        {
            pRigid.velocity = new Vector2(pRigid.velocity.x, pRigid.velocity.y * 0.5f);
        }
    }

    void Dash()
    {
        if (pInput.dash && canDash)
        {
            isDashing = true;
            canDash = false;
            trailRenderer.emitting = true;
            dashDir = new Vector2(pInput.lrInput, pInput.tbInput);

            if(dashDir == Vector2.zero)
            {
                dashDir = new Vector2(transform.localScale.x, 0);
            }

            StartCoroutine(StopDashing());
        }

        if(isDashing)
        {
            pRigid.velocity = dashDir.normalized * dashSpeed;
            return;
        }

        if (isGround) canDash = true;
    }

    IEnumerator StopDashing()
    {
        yield return new WaitForSeconds(dashTime);
        trailRenderer.emitting = false;
        isDashing = false;
    }

    void WallHanging()
    {
        isWallHanging = false;

        if (!isFront || isGround) return;
        
        if ((transform.localScale.x == 1f && pInput.lrInput > 0) || 
            (transform.localScale.x == -1f && pInput.lrInput < 0))
            isWallHanging = true;

        if(isWallHanging)
        {
            pRigid.gravityScale = 0f;
            pRigid.velocity = Vector2.zero;
        }
        else
        {
            pRigid.gravityScale = gravityStore;
        }
    }

    void WallJump()
    {
        if (isWallHanging && pInput.jumpButtonDown)
        {
            wallJumpCounter = wallJumpTime;

            pRigid.velocity = new Vector2(-pInput.lrInput * defaultMoveSpeed, jumpForce);
            pRigid.gravityScale = gravityStore;
            isWallHanging = false;
        }
    }

    void WallMove()
    {
        if (!isWallHanging) return;

        wallMoveSpeed = pInput.tbInput > 0 ? 0.35f : 1;
        pRigid.velocity = new Vector2(pRigid.velocity.x, pInput.tbInput * moveSpeed * wallMoveSpeed);
    }

    void CheckObject()
    {
        isGround = 
            Physics2D.OverlapCircle(groundCheck.position, checkRadius, groundLayer);

        isFront =
            Physics2D.OverlapCircle(frontCheck.position, checkRadius, frontLayer);
    }

    void FlipPlayer()
    {
        if (pRigid.velocity.x > 0)
            transform.localScale = Vector3.one;
        else if (pRigid.velocity.x < 0)
            transform.localScale = new Vector3(-1f, 1, 1f);
    }
}
